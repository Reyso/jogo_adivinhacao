import time
import os

def carregar_palavras_secretas():
    if not os.path.exists(".palavras_secretas.txt"):
        print("Arquivo '.palavras_secretas.txt' não encontrado!")
        exit()
    palavras_secretas = []
    with open(".palavras_secretas.txt", "r") as arquivo:
        for linha in arquivo:
            palavras_secretas.append(linha.strip())
    return palavras_secretas

def verificar_tentativas(palavra_chave, tentativas):
    resultado = {}
    for tentativa in tentativas:
        tamanho_util = min(len(tentativa), len(palavra_chave))  # Limitar à menor palavra
        posicoes_corretas = []
        for i in range(tamanho_util):
            if tentativa[i] == palavra_chave[i]:
                posicoes_corretas.append(i)
            elif tentativa[i] in palavra_chave:
                print(f"A letra '{tentativa[i]}' está na palavra secreta, mas na posição errada.")
        resultado[tentativa] = posicoes_corretas
    return resultado

def mostrar_progresso(palavra_chave, tentativas):
    progresso = ["_" for _ in palavra_chave]
    for tentativa in tentativas:
        tamanho_util = min(len(tentativa), len(palavra_chave))  # Ajustar ao menor comprimento
        for i in range(tamanho_util):
            if tentativa[i] == palavra_chave[i]:
                progresso[i] = tentativa[i]
    print("Progresso: " + " ".join(progresso))

def main():
    palavras_secretas = carregar_palavras_secretas()
    print("Escolha uma das palavras secretas:")
    for i, palavra in enumerate(palavras_secretas, start=1):
        print(f"{i}. Palavra secreta com {len(palavra)} letras ")
    escolha = int(input("\n------------------------Digite o número da palavra secreta para iniciar o jogo: "))
    palavra_chave = palavras_secretas[escolha - 1]

    print(f"A palavra chave tem {len(palavra_chave)} letras.")

    if not os.path.exists("tentativas.txt"):
        print("Arquivo 'tentativas.txt' não encontrado!")
        return

    with open("tentativas.txt", "r") as arquivo:
        tentativas = arquivo.read().splitlines()

    resultado = verificar_tentativas(palavra_chave, tentativas)
    for tentativa, posicoes_corretas in resultado.items():
        if posicoes_corretas:
            print(f"\n------------------------Tentativa: {tentativa} - Letras corretas nas posições: {posicoes_corretas}--------------------------")
        else:
            print(f"Tentativa: {tentativa} - Nenhuma letra correta")
        mostrar_progresso(palavra_chave, tentativas)
        time.sleep(1)

    if palavra_chave in tentativas:
        print("\n------------------------Parabéns! Você acertou a palavra secreta!--------------------------")
    else:
        print(f"\n------------------------Que pena! tente novamente-------------------------")

if __name__ == "__main__":
    main()