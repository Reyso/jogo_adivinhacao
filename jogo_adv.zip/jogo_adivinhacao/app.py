import time
import os

def carregar_palavras_secretas():
    palavras_secretas = []
    with open(".palavras_secretas.txt", "r") as arquivo:
        for linha in arquivo:
            palavras_secretas.append(linha.strip())
    return palavras_secretas

def verificar_tentativas(palavra_chave, tentativas):
    resultado = {}
    for tentativa in tentativas:
        if len(tentativa) != len(palavra_chave):
            resultado[tentativa] = "Tamanho incorreto"
            continue
        posicoes_corretas = []
        for i, letra in enumerate(tentativa):
            if letra == palavra_chave[i]:
                posicoes_corretas.append(i)
        resultado[tentativa] = posicoes_corretas
    return resultado

def main():
    palavras_secretas = carregar_palavras_secretas()
    print("Escolha uma das palavras secretas:")
    for i, palavra in enumerate(palavras_secretas, start=1):
        print(f"{i}. Palavra secreta {i}")
    escolha = int(input("Digite o número da palavra secreta para iniciar o jogo: "))
    palavra_chave = palavras_secretas[escolha - 1]

    num_letras = len(palavra_chave)
    print(f"A palavra chave tem {num_letras} letras.")

    if not os.path.exists("tentativas.txt"):
        print("Arquivo de tentativas não encontrado!")
        return

    with open("tentativas.txt", "r") as arquivo:
        tentativas = arquivo.read().splitlines()

    resultado = verificar_tentativas(palavra_chave, tentativas)
    for tentativa, posicoes_corretas in resultado.items():
        if posicoes_corretas == "Tamanho incorreto":
            print(f"Tentativa: {tentativa} - Tamanho incorreto")
        elif posicoes_corretas:
            print(f"Tentativa: {tentativa} - Letras corretas nas posições: {posicoes_corretas}")
        else:
            print(f"Tentativa: {tentativa} - Nenhuma letra correta")
        time.sleep(1)

if __name__ == "__main__":
    main()

